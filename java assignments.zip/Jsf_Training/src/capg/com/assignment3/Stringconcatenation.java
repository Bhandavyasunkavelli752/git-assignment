package capg.com.assignment3;

public class Stringconcatenation{  
	 public static void main(String args[]){  
		   String s1="hello ";  
		   String s2="how r u";  
		   String s3=s1.concat(s2);  
		   System.out.println(s3); 
		  }  
		}