package capg.com.assignment3;

public class Length {
	public  static void main(String[] args) {
		String str="testing";
		int count = str.length();
		System.out.println("the string has"+count+"characters");
	}
	
	

}